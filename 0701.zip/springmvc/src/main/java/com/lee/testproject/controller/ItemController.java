package com.lee.testproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ItemController {
	@RequestMapping(value = "/create" , method = RequestMethod.GET)
	public ModelAndView create() {
		return new ModelAndView("item/create");
	}
	@RequestMapping(value = "/create" , method = RequestMethod.POST)
	public ModelAndView createPost() {
		
		return new ModelAndView("item/create");
	}
}
