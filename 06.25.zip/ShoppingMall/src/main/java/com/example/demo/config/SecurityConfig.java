package com.example.demo.config;

import static org.springframework.security.config.Customizer.withDefaults;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
//@EnableWebSecurity 인코딩만 살리기
public class SecurityConfig {

//	@Bean
//	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//
//		http.authorizeHttpRequests(auth -> auth.requestMatchers("/members/**").permitAll());
//		http.authorizeHttpRequests(auth -> auth.requestMatchers("/index").permitAll());
//		http.authorizeHttpRequests(
//				(authorizeHttpRequests) -> authorizeHttpRequests.requestMatchers("/**").hasRole("USER"))
//				.formLogin( (formLogin)->
//					formLogin.loginPage("/members/login")
//					.defaultSuccessUrl("/index")
//					.usernameParameter("email")
////					.failureUrl("/members/login/error")
//					)		
//				.logout( (logout)->
//					logout.deleteCookies("remove")
//					.invalidateHttpSession(false)
//					.logoutUrl("/members/logout")
//					.logoutSuccessUrl("/index")
//				);
//		return http.build();
//	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
