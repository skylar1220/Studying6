package com.lee.testproject.controller;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.lee.testproject.dao.service.MemberService;

@Controller
public class MemberController {
	@Autowired
	MemberService memberService;
	
	
	@GetMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("/member/login");
	}
	
	@PostMapping("/login")
	@ResponseBody
	public String login_post(@RequestParam Map<String, Object> map,
		HttpServletRequest req ) throws Exception {
		
		boolean isMember =  memberService.getMember(map);
		HttpSession session =  req.getSession();
		if(isMember) {
			session.setAttribute("email", map.get("email"));
			return "success";
		}
		throw new Exception("로그아웃 실패");			
	}
	
	@PostMapping("/logout")
	@ResponseBody
	public String logout(HttpServletRequest req) {
		HttpSession session =  req.getSession();
		session.invalidate();
		return "success";
	}
	
	@GetMapping("/regist")
	public ModelAndView regist() {
		return new ModelAndView("/member/regist");
	}
	
	@PostMapping("/checklogin")
	@ResponseBody
	public String checklogin(@RequestBody String email) throws Exception {
		String decodeEmail =  URLDecoder.decode(email,StandardCharsets.UTF_8);
		decodeEmail  =decodeEmail.replace("=", "");
		Map<String, Object> map = new HashMap<String, Object>();
		System.out.println(decodeEmail);
		map.put("email", decodeEmail);
		boolean isMember =  memberService.getMember(map);
		if(isMember)		
			return "true";
		else
			return "false";
	}
	
}
