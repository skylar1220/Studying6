package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


//@Configuration
//@EnableWebSecurity  // 안되서 일단 막고
public class SecurityConfig  {
	
//	@Bean
//	public WebSecurityCustomizer webSecurityCustomizer() {
//		return (web) -> web.ignoring().requestMatchers("/members/new") ;
//	}
//	
//	
//	@Bean	// repository 할 때 자동으로 객체 만들어서 넣어주는 것?
//	public PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder();
//	}
//	
//	// 비번 일치 오류나서
//	
	
}
