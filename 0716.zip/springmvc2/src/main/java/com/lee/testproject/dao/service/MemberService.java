package com.lee.testproject.dao.service;

import java.util.Map;

public interface MemberService {

	boolean getMember(Map<String, Object> map);
}
