package com.example.demo.constant;

public enum Role {
	USER , ADMIN 
}
