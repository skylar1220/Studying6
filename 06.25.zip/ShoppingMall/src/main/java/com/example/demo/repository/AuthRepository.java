package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.constant.Role;
import com.example.demo.entity.Auth;

public interface AuthRepository extends JpaRepository<Auth, Long> {
	 Auth findByAuthRole(Role role) ; 
}
