package com.lee.testproject.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.lee.testproject.dao.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	@GetMapping(value = "/login")
	public ModelAndView login() {
		return new ModelAndView("member/login");
	}
	
	@PostMapping(value = "/login")
	@ResponseBody //니까 아래 함수가 스트링인 거 
	public String login_post(@RequestParam Map<String, Object> map
		, HttpServletRequest req ) throws Exception {
		boolean isMember =  memberService.getMember(map);
		HttpSession session =  req.getSession();
		if(isMember) {
			session.setAttribute("email", map.get("email"));
			return "success"; // 멤버면 string 반환 / else 해주지 않음: 실패했는데 화면제출post하고 떠나면 안되니까 ajax로 구현해서 머무르게
		}
		throw new Exception("로그인 실패");  // 실패했을 때는 문자열이 아니라 아예 이셉션을 던지게 , null도 문자열로 인식햇 
	}
	
	@PostMapping(value = "/logout")
	@ResponseBody
	public String logout(HttpServletRequest req) {
		HttpSession session =  req.getSession();
		session.invalidate();
		return "success";
	}
	
}
